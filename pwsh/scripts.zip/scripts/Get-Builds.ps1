param(
    [Parameter(Mandatory = $true)][string]$Org,
    [Parameter(Mandatory = $true)][string]$Project,
    [Parameter(Mandatory = $true)][string]$PAT,
    [Parameter(Mandatory = $true)][string]$Branch,
    [Parameter(Mandatory = $true)][string]$OutputPath
)

$ErrorActionPreference = "Stop"

$headers = @{
    Authorization = "Basic $([Convert]::ToBase64String([Text.Encoding]::ASCII.GetBytes(":$PAT")))"
}

$url = "https://devops/$Org/$Project/_apis/build/builds?definitions=7&branchName=$Branch&queryOrder=finishTimeDescending&api-version=6.0"
Write-Host "Calling $url..."

$response = Invoke-RestMethod -Uri $url -Headers $headers -Method Get

$response | ConvertTo-Json -Depth 10 | Out-File $OutputPath

Write-Host "Retrieved $($response.count) builds for definitionId=7 on branch $Branch."
Write-Host "Saved builds metadata to $OutputPath"