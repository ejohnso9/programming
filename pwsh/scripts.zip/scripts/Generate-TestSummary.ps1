param(
    [string]$TestResultsPath,
    [string]$OutputDir
)

# Load TRX file
[xml]$trx = Get-Content $TestResultsPath
$results = $trx.TestRun.Results.UnitTestResult

# Calculate counts
$passed  = ($results | Where-Object { $_.outcome -eq "Passed" }).Count
$failed  = ($results | Where-Object { $_.outcome -eq "Failed" }).Count
$skipped = ($results | Where-Object { $_.outcome -eq "NotExecuted" }).Count

$effectiveTotal = $passed + $failed   # exclude skipped
$passRate = if ($effectiveTotal -gt 0) {
    [math]::Round(($passed / $effectiveTotal) * 100, 2)
} else {
    0
}

# Build a hashtable of individual test results
$testResults = @{}
foreach ($t in $results) {
    # Use the test name as key and outcome as value
    $testResults[$t.testName] = $t.outcome
}

# Build summary object
$summary = [PSCustomObject]@{
    Passed      = $passed
    Failed      = $failed
    Skipped     = $skipped
    PassRate    = $passRate
    TestDetails = $testResults
}

# Ensure output directory exists
New-Item -ItemType Directory -Force -Path $OutputDir | Out-Null
$jsonFile = Join-Path $OutputDir "test-summary.json"

# Write JSON file
$summary | ConvertTo-Json -Depth 5 | Set-Content -Path $jsonFile -Encoding UTF8

Write-Host "Test summary saved to $jsonFile"