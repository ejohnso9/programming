param(
    [Parameter(Mandatory = $true)][string]$Org,
    [Parameter(Mandatory = $true)][string]$Project,
    [Parameter(Mandatory = $true)][string]$PAT,
    [Parameter(Mandatory = $true)][string]$ArtifactName,
    [Parameter(Mandatory = $true)][string]$BuildsFile,
    [Parameter(Mandatory = $true)][string]$OutputPath
)

$ErrorActionPreference = "Stop"

$headers = @{
    Authorization = "Basic $([Convert]::ToBase64String([Text.Encoding]::ASCII.GetBytes(":$PAT")))"
}

$builds = (Get-Content $BuildsFile | ConvertFrom-Json).value
$selectedArtifacts = @()

foreach ($build in $builds) {
    $buildId = $build.id
    Write-Host "Fetching artifacts for buildId=$buildId ..."

    $url = "https://devops/$Org/$Project/_apis/build/builds/$buildId/artifacts?api-version=6.0"
    $response = Invoke-RestMethod -Uri $url -Headers $headers -Method Get

    if ($null -ne $response -and $response.value) {
        $artifact = $response.value | Where-Object { $_.name -eq $ArtifactName }
        if ($artifact) {
            Write-Host "Found artifact '$ArtifactName' for buildId=$buildId."

            $selectedArtifacts += [PSCustomObject]@{
                buildId        = $build.id
                buildNumber    = $build.buildNumber
                status         = $build.status
                result         = $build.result
                queueTime      = $build.queueTime
                startTime      = $build.startTime
                finishTime     = $build.finishTime
                sourceBranch   = $build.sourceBranch
                sourceVersion  = $build.sourceVersion
                requestedFor   = $build.requestedFor.displayName
                artifactName   = $artifact.name
                artifactUrl    = $artifact.resource.downloadUrl
                artifactType   = $artifact.resource.type
            }
        } else {
            Write-Host "Artifact '$ArtifactName' not found for buildId=$buildId."
        }
    }
}

if ($selectedArtifacts.Count -eq 0) {
    Write-Warning "No artifacts found matching '$ArtifactName' in any builds."
}

# Convert objects to JSON (without unwanted escaping)
$json = $selectedArtifacts | ConvertTo-Json -Depth 10

# Decode escaped Unicode sequences like \u0026, \u003c, \u003e
# This restores &, <, and > for readability and use in URLs
$json = $json -replace '\\u0026', '&' -replace '\\u003c', '<' -replace '\\u003e', '>'

# Write the cleaned JSON to the output file
$json | Out-File -FilePath $OutputPath -Encoding UTF8
Write-Host "Saved selected artifact metadata (with build details) to $OutputPath"
