param(
    [Parameter(Mandatory=$true)][string]$PipelineWorkspace,
    [Parameter(Mandatory=$true)][string]$Repo,
    [Parameter(Mandatory=$true)][string]$BuildConfiguration
)

Write-Host "Preparing output directory..."
$testOutputDir = Join-Path $PipelineWorkspace "test-output"
mkdir $testOutputDir -Force | Out-Null

$xmlOut  = Join-Path $PipelineWorkspace "unit-tests-$Repo-$BuildConfiguration.xml"
$jsonOut = Join-Path $PipelineWorkspace "unit-tests-$Repo-$BuildConfiguration.json"

Write-Host "Running unit tests..."
$testExe = Join-Path $PipelineWorkspace "$Repo-build-$BuildConfiguration\$Repo-UnitTests"
& $testExe --gtest_output=xml:$xmlOut

Write-Host "Converting XML to JSON..."

function Convert-XmlNodeToHashtable {
    param ([System.Xml.XmlNode]$node)
    $hash = @{}

    # Include attributes
    if ($node.Attributes) {
        foreach ($attr in $node.Attributes) {
            $hash["@$($attr.Name)"] = $attr.Value
        }
    }

    # Process children
    foreach ($child in $node.ChildNodes) {
        if ($child.NodeType -eq 'Element') {
            if ($child.HasChildNodes -and $child.ChildNodes.Count -eq 1 -and $child.FirstChild.NodeType -eq 'Text') {
                $hash[$child.Name] = $child.InnerText
            } else {
                if ($hash.ContainsKey($child.Name)) {
                    if (-not ($hash[$child.Name] -is [System.Collections.IList])) {
                        $hash[$child.Name] = @($hash[$child.Name])
                    }
                    $hash[$child.Name] += ,(Convert-XmlNodeToHashtable $child)
                } else {
                    $hash[$child.Name] = Convert-XmlNodeToHashtable $child
                }
            }
        }
    }

    # Include text if element has no children
    if (-not $hash.Keys.Count -and $node.InnerText) {
        return $node.InnerText
    }

    return $hash
}

# Parse XML and convert to hashtable
$xml = [xml](Get-Content $xmlOut)
$data = Convert-XmlNodeToHashtable $xml.DocumentElement

# Build summary
$root = $xml.DocumentElement
$tests    = [int]$root.tests
$failures = [int]$root.failures
$disabled = [int]$root.disabled
$errors   = [int]$root.errors
$passed   = $tests - $failures - $disabled - $errors

$summary = @{
    total    = $tests
    passed   = $passed
    failed   = $failures
    disabled = $disabled
    errors   = $errors
}

# Final output object
$output = @{
    testsuites = $data
    summary    = $summary
}

$json = $output | ConvertTo-Json -Depth 100
$json | Out-File -FilePath $jsonOut -Encoding utf8

Write-Host "JSON file written to $jsonOut"
