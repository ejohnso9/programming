param (
    [Parameter(Mandatory)]
    [string]$JsonPath,

    [string]$WorkItemType = "Requirement",
    [string]$AssignedTo = "",
    [string]$AreaPath = "",
    [string]$IterationPath = "",
    [string]$BaseTags = "AutomatedTest",
    [string]$Repo = ""
)

$ErrorActionPreference = "Stop"

$org     = 'AFNWC_MOD_SIM'
$project = 'NHDBS_Science'
$token   = $env:SYSTEM_ACCESSTOKEN

if (-not $token) {
    throw "System.AccessToken not available. Enable 'Allow scripts to access OAuth token'."
}

$baseHeaders = @{
    Authorization = "Bearer $token"
    "Content-Type" = "application/json"
}

#------------------------------------------------------------
# Load and parse test results
#------------------------------------------------------------
$results = Get-Content $JsonPath -Raw | ConvertFrom-Json
$testDetails = $results.TestDetails

#------------------------------------------------------------
# Helper: Extract case number from test name (e.g., 'SomeTest_Test ("Case00000")' -> "Case00000")
#------------------------------------------------------------
function Get-CaseNumber {
    param([string]$TestName)
    
    if ($TestName -match '\("(Case\d+)"\)') {
        return $Matches[1]
    }
    return $null
}

#------------------------------------------------------------
# Helper: Extract test name without case number (e.g., 'SomeTest_Test ("Case00000")' -> "SomeTest_Test")
#------------------------------------------------------------
function Get-TestName {
    param([string]$FullTestName)
    
    if ($FullTestName -match '^(.+?)\s+\("Case\d+"\)$') {
        return $Matches[1]
    }
    return $FullTestName
}

#------------------------------------------------------------
# Helper: Find existing work item by case number
#------------------------------------------------------------
function Get-WorkItemByCaseNumber {
    param([string]$CaseNumber)

    $wiql = @{
        query = @"
SELECT [System.Id]
FROM WorkItems
WHERE
    [System.TeamProject] = '$project'
    AND [System.WorkItemType] = '$WorkItemType'
    AND [System.Title] = '$Repo::$CaseNumber'
"@
    } | ConvertTo-Json

    $response = Invoke-RestMethod `
        -Method Post `
        -Uri "https://devops/$org/$project/_apis/wit/wiql?api-version=6.0" `
        -Headers $baseHeaders `
        -Body $wiql

    return $response.workItems.id
}

#------------------------------------------------------------
# Helper: Get work item details
#------------------------------------------------------------
function Get-WorkItem {
    param([int]$Id)

    $uri = "https://devops/$org/$project/_apis/wit/workitems/$($Id)?api-version=6.0"
    
    return Invoke-RestMethod `
        -Method Get `
        -Uri $uri `
        -Headers $baseHeaders
}

#------------------------------------------------------------
# Helper: Create work item for case number
#------------------------------------------------------------
function New-CaseWorkItem {
    param (
        [Parameter(Mandatory)]
        [string]$CaseNumber,

        [Parameter(Mandatory)]
        [string]$Description,

        [string]$Tags
    )
    $title = "$Repo::$CaseNumber"
    $patch = @(
        @{ op = "add"; path = "/fields/System.Title"; value = $title }
        @{ op = "add"; path = "/fields/System.Description"; value = $Description }
        @{ op = "add"; path = "/fields/System.State"; value = "Proposed" }
        @{ op = "add"; path = "/fields/System.AssignedTo"; value = "" }
    )

    if ($Tags) {
        $patch += @{ op = "add"; path = "/fields/System.Tags"; value = $Tags }
    }
    if ($AreaPath) {
        $patch += @{ op = "add"; path = "/fields/System.AreaPath"; value = $AreaPath }
    }
    if ($IterationPath) {
        $patch += @{ op = "add"; path = "/fields/System.IterationPath"; value = $IterationPath }
    }

    $response = Invoke-RestMethod `
        -Method Patch `
        -Uri "https://devops/$org/$project/_apis/wit/workitems/`$Requirement?api-version=6.0" `
        -Headers @{
            Authorization = "Bearer $token"
            "Content-Type" = "application/json-patch+json"
        } `
        -Body ($patch | ConvertTo-Json -Depth 5)

    Write-Host "Created work item #$($response.id) for $CaseNumber"
    return $response.id
}

#------------------------------------------------------------
# Helper: Update work item state and tags
#------------------------------------------------------------
function Update-WorkItem {
    param (
        [Parameter(Mandatory)]
        [int]$Id,

        [Parameter(Mandatory)]
        [string]$State,

        [string]$Reason,
        [string]$Tags,
        [string]$Description,
        [string]$AssignTo,
        [string]$Replace
    )

    $uri = "https://devops/$org/$project/_apis/wit/workitems/$($Id)?api-version=6.0"
    $workItem = Invoke-RestMethod `
        -Method Get `
        -Uri $uri `
        -Headers $baseHeaders
    
    $patch = @(
        @{ op = "add"; path = "/fields/System.State"; value = $State }
    )

    if ($Reason) {
        $patch += @{ op = "add"; path = "/fields/System.Reason"; value = $Reason }
    }
    if ($Tags) {
        $patch += @{ op = "replace"; path = "/fields/System.Tags"; value = $Tags }
    }
    if ($Description) {
        $patch += @{ op = "replace"; path = "/fields/System.Description"; value = $Description }
    }
    if ($AssignTo) {
        if (-not $workItem.fields.'System.AssignedTo') {
            $patch += @{ op = "add"; path = "/fields/System.AssignedTo"; value = $AssignTo }
        }
    }

    Invoke-RestMethod `
        -Method Patch `
        -Uri $uri `
        -Headers @{
            Authorization = "Bearer $token"
            "Content-Type" = "application/json-patch+json"
        } `
        -Body ($patch | ConvertTo-Json -Depth 5)

    Write-Host "Updated work item #$Id to $State"
}

#------------------------------------------------------------
# Group tests by case number
#------------------------------------------------------------
$caseGroups = @{}

foreach ($testName in $testDetails.PSObject.Properties.Name) {
    $caseNumber = Get-CaseNumber -TestName $testName
    
    if (-not $caseNumber) {
        Write-Warning "Could not extract case number from: $testName"
        continue
    }

    if (-not $caseGroups.ContainsKey($caseNumber)) {
        $caseGroups[$caseNumber] = @{
            Passed = @()
            Failed = @()
            NotExecuted = @()
        }
    }

    $status = $testDetails.$testName
    $cleanTestName = Get-TestName -FullTestName $testName
    
    switch ($status) {
        "Passed"      { $caseGroups[$caseNumber].Passed += @{ Full = $testName; Clean = $cleanTestName } }
        "Failed"      { $caseGroups[$caseNumber].Failed += @{ Full = $testName; Clean = $cleanTestName } }
        "NotExecuted" { $caseGroups[$caseNumber].NotExecuted += @{ Full = $testName; Clean = $cleanTestName } }
        default       { Write-Warning "Unknown status '$status' for: $testName" }
    }
}

#------------------------------------------------------------
# Process each case number
#------------------------------------------------------------
foreach ($caseNumber in $caseGroups.Keys | Sort-Object) {
    $tests = $caseGroups[$caseNumber]
    $failedTests = $tests.Failed + $tests.NotExecuted
    $hasFailures = $failedTests.Count -gt 0
    
    # Build tags with clean test names (X_Test only)
    $tagList = @($BaseTags)
    if ($hasFailures) {
        $tagList += $failedTests | ForEach-Object { $_.Clean }
    }
    $tags = $tagList -join ";"
    
    # Build description with full test names
    $descriptionParts = @("## Test Results for $caseNumber`n")
    
    if ($tests.Passed.Count -gt 0) {
        $descriptionParts += "**Passed ($($tests.Passed.Count)):**"
        $descriptionParts += $tests.Passed | ForEach-Object { "- $($_.Full)" }
        $descriptionParts += ""
    }
    
    if ($tests.Failed.Count -gt 0) {
        $descriptionParts += "**Failed ($($tests.Failed.Count)):**"
        $descriptionParts += $tests.Failed | ForEach-Object { "- $($_.Full)" }
        $descriptionParts += ""
    }
    
    if ($tests.NotExecuted.Count -gt 0) {
        $descriptionParts += "**Not Executed ($($tests.NotExecuted.Count)):**"
        $descriptionParts += $tests.NotExecuted | ForEach-Object { "- $($_.Full)" }
        $descriptionParts += ""
    }
    
    $description = $descriptionParts -join "`n"
    
    # Check if work item exists
    $existingId = Get-WorkItemByCaseNumber -CaseNumber $caseNumber
    
    if ($hasFailures) {
        if ($existingId) {
            $workItem = Get-WorkItem -Id $existingId
            $currentState = $workItem.fields.'System.State'
            
            if ($currentState -eq "Resolved") {
                # Reopen the work item
                Write-Host "Reopening work item #$existingId for $caseNumber (has failures)"
                Update-WorkItem -Id $existingId -State "Active" -Reason "Validation Test Failed" -Tags $tags -Description $description -AssignTo $AssignedTo
                Update-WorkItem -Id $existingId -State "Proposed" -Reason "Postponed"
            }
            else {
                # Update existing open work item
                Write-Host "Updating work item #$existingId for $caseNumber"
                Update-WorkItem -Id $existingId -State $currentState -Tags $tags -Description $description
            }
        }
        else {
            # Create new work item
            Write-Host "Creating work item for $caseNumber (has failures)"
            New-CaseWorkItem -CaseNumber $caseNumber -Description $description -Tags $tags
        }
    }
    else {
        # All tests passed
        if ($existingId) {
            $workItem = Get-WorkItem -Id $existingId
            $currentState = $workItem.fields.'System.State'
            
            if ($currentState -in @("Proposed", "Active")) {
                # Resolve the work item
                Write-Host "Resolving work item #$existingId for $caseNumber (all tests passed)"
                Update-WorkItem -Id $existingId -State "Active" -Tags $tags -Reason "Accepted" -Description $description -AssignTo $AssignedTo
                Update-WorkItem -Id $existingId -State "Resolved" -Reason "Code Complete and System Test Passed"
            }
            else {
                Write-Host "Work item #$existingId for $caseNumber already resolved"
            }
        }
        else {
            Write-Host "All tests passed for $caseNumber - no work item needed"
        }
    }
}

Write-Host "`nProcessing complete. Processed $($caseGroups.Count) case(s)."