param(
    [string]$BaselineFile,
    [string]$CurrentFile
)

if (-Not (Test-Path $BaselineFile)) {
    Write-Host "No baseline found - treating current results as baseline."
    exit 0
}

$current  = Get-Content $CurrentFile  | ConvertFrom-Json
$baseline = Get-Content $BaselineFile | ConvertFrom-Json

$currentTotal  = [int]$current.Passed + [int]$current.Failed
$baselineTotal = [int]$baseline.Passed + [int]$baseline.Failed

# Prepare output directory and diff file
$summaryDir  = "test-summary"
$diffFile    = Join-Path -Path $summaryDir -ChildPath "diff.txt"

if (-not (Test-Path $summaryDir)) {
    New-Item -Path $summaryDir -ItemType Directory -Force | Out-Null
}

# Start fresh
"" | Out-File -FilePath $diffFile -Encoding UTF8

# Compare pass rates
if ([double]$current.PassRate -lt [double]$baseline.PassRate) {
    if ($currentTotal -gt $baselineTotal) {
        $msg = "Pass rate decreased ($($current.PassRate)% < $($baseline.PassRate)%), but total test count increased ($currentTotal vs $baselineTotal) � allowing."
        Write-Host $msg
        Add-Content -Path $diffFile -Value $msg
    }
    elseif ($currentTotal -lt $baselineTotal) {
        $msg = "Pass rate decreased, but total test count decreased ($currentTotal vs $baselineTotal) � allowing."
        Write-Host $msg
        Add-Content -Path $diffFile -Value $msg
    }
    else {
        $msg = "Current pass rate ($($current.PassRate)%) is lower than baseline ($($baseline.PassRate)%) and total test count stayed the same ($currentTotal)"
        Write-Error $msg
        Add-Content -Path $diffFile -Value $msg
    }
}
else {
    $msg = "Current pass rate ($($current.PassRate)%) is OK (>= baseline $($baseline.PassRate)%)."
    Write-Host $msg
    Add-Content -Path $diffFile -Value $msg
}

# --- DIFF: compare individual test results ---
Write-Host "`nDiffing individual tests:"
Add-Content -Path $diffFile -Value "`nDiffing individual tests:"

$failDueToRegression = $false

$allTests = $current.TestDetails.Keys + $baseline.TestDetails.Keys | Sort-Object -Unique

foreach ($test in $allTests) {
    $baseOutcome = $baseline.TestDetails[$test]
    $currentOutcome = $current.TestDetails[$test]

    if ($baseOutcome -ne $currentOutcome) {
        $diffMsg = "Test '$test' changed: $baseOutcome -> $currentOutcome"
        Write-Host $diffMsg
        Add-Content -Path $diffFile -Value $diffMsg

        # If test regressed from Passed -> Failed, mark failure
        if ($baseOutcome -eq "Passed" -and $currentOutcome -eq "Failed") {
            $failDueToRegression = $true
        }
    }
}

if ($failDueToRegression) {
    $failMsg = "`nOne or more tests regressed from Passed to Failed. Failing job."
    Write-Error $failMsg
    Add-Content -Path $diffFile -Value $failMsg
    exit 1
}