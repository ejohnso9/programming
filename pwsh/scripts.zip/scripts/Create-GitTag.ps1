param(
    [int]$major = 0,
    [int]$minor = 0,
    [int]$patch = 0,
    [string]$branch = ""
)

Write-Host "##[group]Fetching tags..."
git fetch --tags --quiet
Write-Host "##[endgroup]"

# Get the latest tag (sorted by version, stripping leading 'v' if present)
$latestTag = git tag | Where-Object { $_ -match '^v?\d+\.\d+\.\d+\.\d+$' } |
    Sort-Object {[version]($_ -replace '^v','')} | Select-Object -Last 1

if (-not $latestTag) {
    $build = 0
    $newVersion = "$major.$minor.$patch.$build"
    $newTag = "v$newVersion"
    Write-Host "No existing tags found. Creating initial tag: $newTag"
}
else {
    Write-Host "Latest tag: $latestTag"

    # Strip 'v' if present and split version parts
    $versionString = $latestTag -replace '^v',''
    $parts = $versionString -split '\.'
    $oldmajor = [int]$parts[0]
    $oldminor = [int]$parts[1]
    $oldpatch = [int]$parts[2]
    $build = [int]$parts[3]

    if ($major -gt $oldmajor -or
        ($major -eq $oldmajor -and $minor -gt $oldminor) -or
        ($major -eq $oldmajor -and $minor -eq $oldminor -and $patch -gt $oldpatch)) {
        Write-Host "Version increased ($oldmajor.$oldminor.$oldpatch -> $major.$minor.$patch). Resetting build to 0."
        $build = 0
    }
    elseif ($branch -eq "refs/heads/dev") {
        Write-Host "On dev branch – incrementing build number."
        $build += 1
    }
    else {
        Write-Host "Not on dev branch – keeping build number unchanged."
    }

    $newVersion = "$major.$minor.$patch.$build"
    $newTag = "v$newVersion"
}

Write-Host "New tag: $newTag"

# Only tag and push if on 'dev' branch
if ($branch -eq "refs/heads/dev") {
    Write-Host "Creating and pushing tag..."
    git tag $newTag
    git push origin $newTag
    Write-Host "Tag $newTag pushed to remote."
}
else {
    Write-Host "Skipping tag push (not on dev branch)."
}

# Return build number to pipeline
Write-Host "##vso[task.setvariable variable=BUILDNUMBER;isOutput=true]$build"
