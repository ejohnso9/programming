param(
    [Parameter(Mandatory = $true)][string]$PAT,
    [Parameter(Mandatory = $true)][string]$ArtifactsFile,
    [Parameter(Mandatory = $true)][string]$OutputDir
)

$ErrorActionPreference = "Stop"

$headers = @{
    Authorization = "Basic $([Convert]::ToBase64String([Text.Encoding]::ASCII.GetBytes(":$PAT")))"
}

$artifacts = Get-Content $ArtifactsFile | ConvertFrom-Json

if (!(Test-Path $OutputDir)) {
    New-Item -ItemType Directory -Path $OutputDir | Out-Null
}

$counter = 0

foreach ($artifact in $artifacts) {
    $buildId = $artifact.buildId
    $name = $artifact.artifactName
    $downloadUrl = $artifact.artifactUrl

    if (-not $downloadUrl) {
        Write-Warning "No download URL for artifact '$name' (buildId=$buildId)"
        continue
    }

    $zipPath = Join-Path $OutputDir "$($buildId)_$($name).zip"
    $extractPath = Join-Path $OutputDir "$($buildId)_$($name)"

    Write-Host "Downloading artifact '$name' from build $buildId..."
    Invoke-WebRequest -Uri $downloadUrl -Headers $headers -OutFile $zipPath

    Write-Host "Extracting to $extractPath ..."
    Expand-Archive -Path $zipPath -DestinationPath $extractPath -Force

    $counter++
}

Write-Host "Downloaded and extracted $counter artifact(s) to $OutputDir."