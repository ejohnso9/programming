[CmdletBinding()]
param(
    [string] $RepoRoot  = $(if ($env:BUILD_SOURCESDIRECTORY)   { $env:BUILD_SOURCESDIRECTORY }   else { (Get-Location).Path }),
    [string] $OutputDir = $(if ($env:BUILD_ARTIFACTSTAGINGDIRECTORY) { $env:BUILD_ARTIFACTSTAGINGDIRECTORY } else { (Get-Location).Path }),
    [string] $ZipName   = "src-all.zip"
)
 
Set-StrictMode -Version Latest
$ErrorActionPreference = "Stop"
 
# ---------------------------------------------------------------------------
# 1. Resolve paths
# ---------------------------------------------------------------------------
$RepoRoot  = (Resolve-Path $RepoRoot).Path
$OutputDir = (Resolve-Path $OutputDir).Path
$ZipPath   = Join-Path $OutputDir $ZipName
 
Write-Host "Repo root  : $RepoRoot"
Write-Host "Output dir : $OutputDir"
Write-Host "Zip path   : $ZipPath"
 
# ---------------------------------------------------------------------------
# 2. Find all src/ folders (repo + submodules), skipping .git internals
# ---------------------------------------------------------------------------
Write-Host "`nScanning for src/ folders..."
 
$srcFolders = Get-ChildItem -Path $RepoRoot `
                -Filter "src" `
                -Directory `
                -Recurse `
                -ErrorAction SilentlyContinue |
              Where-Object {
                $_.FullName -notmatch '[\\/]\.git[\\/]'
              }
 
if (-not $srcFolders) {
    Write-Warning "No src/ folders found under: $RepoRoot"
    exit 0
}
 
Write-Host "Found $($srcFolders.Count) src/ folder(s):"
$srcFolders | ForEach-Object {
    $rel = $_.FullName.Substring($RepoRoot.Length).TrimStart('\/'.ToCharArray())
    Write-Host "  $rel"
}
 
# ---------------------------------------------------------------------------
# 3. Stage files into a temp directory (preserving relative paths)
# ---------------------------------------------------------------------------
$staging = Join-Path ([System.IO.Path]::GetTempPath()) "src-staging-$(New-Guid)"
 
Write-Host "`nStaging to: $staging"
New-Item -ItemType Directory -Path $staging | Out-Null
 
foreach ($folder in $srcFolders) {
    $rel  = $folder.FullName.Substring($RepoRoot.Length).TrimStart('\/'.ToCharArray())
    $dest = Join-Path $staging $rel
 
    Write-Host "  Copying: $rel"
    Copy-Item -Path $folder.FullName `
              -Destination $dest `
              -Recurse -Force
}
 
# ---------------------------------------------------------------------------
# 4. Compress to zip
# ---------------------------------------------------------------------------
if (Test-Path $ZipPath) {
    Write-Host "`nRemoving existing zip: $ZipPath"
    Remove-Item $ZipPath -Force
}
 
Write-Host "`nCompressing..."
Compress-Archive -Path "$staging\*" `
                 -DestinationPath $ZipPath `
                 -CompressionLevel Optimal
 
# ---------------------------------------------------------------------------
# 5. Cleanup staging directory
# ---------------------------------------------------------------------------
Remove-Item $staging -Recurse -Force
 
# ---------------------------------------------------------------------------
# 6. Report result
# ---------------------------------------------------------------------------
$sizeMB = [Math]::Round((Get-Item $ZipPath).Length / 1MB, 2)
Write-Host "`nDone."
Write-Host "  Zip : $ZipPath"
Write-Host "  Size: $sizeMB MB"