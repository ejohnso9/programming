#include <stdio.h>
int main(void)
{
   printf("hello\n");
   return 0;
}
