// display.c
#include <stdio.h>
int x = 1;
int main(void)
{
   printf("x = %d\n", x);
   return 0;
}
