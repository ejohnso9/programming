import sys
result = int(sys.argv[1]) + int(sys.argv[2])
print(result)
