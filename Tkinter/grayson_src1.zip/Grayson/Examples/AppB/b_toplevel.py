from Tkinter import *

root = Tk()
root.option_readfile('optionDB')
root.title('Toplevel')
Frame(root, width=150, height=150).pack()
root.mainloop()

